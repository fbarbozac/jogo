/*
	Author: Guilherme & Fernando 
	Date: 10/Ago/2013
	Description: Implementation of a kinf of quiz game in Java.
*/

// Para cada resposta certa, o jogador ganha 1 ponto.
// O jogo acaba quando todas as perguntas forem respondidas.
// A pontuação total deve ser apresentada;
//
/* Requisitos do Jogo:
	1. Fazer a pergunta	
	2. Confirmar a resposta
	3. Guardar a pontuação obtida
	4. Fazer a proxima pergunta (loop)
	5. Quando acabar o loop, apresentar a pontuacao com o nome
*/

class JogoComp
{
	public static void main(String[] args)
	{
		java.io.Console c = System.console();
		int rodadas = 10;

		Pergunta  per = new Pergunta();
		Pontuacao pon = new Pontuacao();
		Resposta con = new Resposta();

		pon.entraNome(c.readLine("Qual seu nome: "));

		while (rodadas > 0)
		{		
			per.escolheOper();
			per.escolhePergunta();

			per.imprimePergunta();
	 		con.armResposta(c.readLine("->:"));

	 		if (con.verifRes(con.gabaritoResposta(per.pergunta1, per.pergunta2, per.oper)))
	 		{
	 		 	pon.pontua();
	 		}
	 		rodadas--;
	 	}
	 	pon.imprimePontos();
	}	
}